﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAIBA_SHEHZAD30;Initial Catalog=TASK1;Integrated Security=True;TrustServerCertificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into util values(@TeacherID,@Name,@Address,@Salary)", con);
            cmd.Parameters.AddWithValue("@TeacherID",(textBox1.Text));
            cmd.Parameters.AddWithValue("@Name", (textBox2.Text));
            cmd.Parameters.AddWithValue("@Address", (textBox3.Text));
            cmd.Parameters.AddWithValue("@Salary", float.Parse(textBox4.Text));


            cmd.ExecuteNonQuery();

            SqlCommand newwcmd = new SqlCommand("select * from util", con);
            SqlDataAdapter da = new SqlDataAdapter(newwcmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            con.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAIBA_SHEHZAD30;Initial Catalog=TASK1;Integrated Security=True;TrustServerCertificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("update util set Name=@Name,Address=@Address,Salary=@Salary where TeacherID=@TeacherID", con);
            cmd.Parameters.AddWithValue("@TeacherID", (textBox1.Text));
            cmd.Parameters.AddWithValue("@Name", (textBox2.Text));
            cmd.Parameters.AddWithValue("@Address", (textBox3.Text));
            cmd.Parameters.AddWithValue("@Salary", float.Parse(textBox4.Text));

            cmd.ExecuteNonQuery();

            SqlCommand newwcmd = new SqlCommand("select * from util", con);
            SqlDataAdapter da = new SqlDataAdapter(newwcmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            con.Close();
         
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAIBA_SHEHZAD30;Initial Catalog=TASK1;Integrated Security=True;TrustServerCertificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("delete util where TeacherID=@TeacherID", con);
            cmd.Parameters.AddWithValue("@TeacherID", (textBox1.Text));

            cmd.ExecuteNonQuery();

            SqlCommand newwcmd = new SqlCommand("select * from util", con);
            SqlDataAdapter da=new SqlDataAdapter(newwcmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAIBA_SHEHZAD30;Initial Catalog=TASK1;Integrated Security=True;TrustServerCertificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from util where TeacherID=@TeacherID", con);
            cmd.Parameters.AddWithValue("@TeacherID", (textBox1.Text));
            SqlDataAdapter da= new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAIBA_SHEHZAD30;Initial Catalog=TASK1;Integrated Security=True;TrustServerCertificate=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from util", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            con.Close();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
